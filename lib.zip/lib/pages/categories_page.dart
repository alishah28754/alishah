// lib/pages/categories_page.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:ktex_home/core/app_colors.dart';
import 'package:ktex_home/core/brand_pattern.dart';
import 'package:ktex_home/models/cart_model.dart';
import 'package:ktex_home/models/favourites_model.dart';
import 'package:ktex_home/models/models.dart';
import 'package:ktex_home/pages/product_detail_page.dart';
import 'package:ktex_home/screens/buy_now_screen.dart';
import 'package:ktex_home/services/api_service.dart';

class CategoriesPage extends StatefulWidget {
  const CategoriesPage({super.key});

  @override
  State<CategoriesPage> createState() => _CategoriesPageState();
}

class _CategoriesPageState extends State<CategoriesPage> with AutomaticKeepAliveClientMixin {
  @override
  bool get wantKeepAlive => true;

  String? _expandedCategory;
  bool _isLoading = true;
  String? _error;

  // ✅ SIX FIXED CATEGORIES - Hardcoded in UI
  final List<CategoryGroup> _categoryGroups = const [
    CategoryGroup(
      title: 'Featured',
      icon: Icons.star_rounded,
      categories: [
        Category(
          name: 'New Arrivals',
          icon: Icons.new_releases_rounded,
          color: Color(0xFFD3AF64),
        ),
        Category(
          name: 'Best Sellers',
          icon: Icons.trending_up_rounded,
          color: Color(0xFFD3AF64),
        ),
        Category(
          name: 'Premium Collection',
          icon: Icons.workspace_premium_rounded,
          color: Color(0xFF8A6B1F),
        ),
      ],
    ),
    CategoryGroup(
      title: 'Shop by Gender',
      icon: Icons.people_rounded,
      categories: [
        Category(
          name: 'Men',
          icon: Icons.man_rounded,
          color: Color(0xFF2C3E50),
        ),
        Category(
          name: 'Women',
          icon: Icons.woman_rounded,
          color: Color(0xFFE74C6F),
        ),
        Category(
          name: 'Kids',
          icon: Icons.face_rounded,
          color: Color(0xFF27AE60),
        ),
      ],
    ),
  ];

  // ✅ DYNAMIC PRODUCTS - Loaded from API
  Map<String, List<Product>> _categoryProducts = {};
  
  // Loading states for each category
  Map<String, bool> _categoryLoading = {};
  Map<String, String?> _categoryErrors = {};

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _loadAllCategoryProducts();
    });
  }

  Future<void> _loadAllCategoryProducts() async {
    setState(() {
      _isLoading = true;
      _error = null;
    });

    try {
      // Fetch all products from API
      final products = await ApiService.instance.fetchProducts(limit: 200);
      
      // Group products by category name
      final Map<String, List<Product>> grouped = {};
      for (var product in products) {
        final category = product.category ?? 'Uncategorized';
        if (!grouped.containsKey(category)) {
          grouped[category] = [];
        }
        grouped[category]!.add(product);
      }

      // Ensure all 6 categories exist in the map (even if empty)
      final allCategoryNames = ['New Arrivals', 'Best Sellers', 'Premium Collection', 'Men', 'Women', 'Kids'];
      for (var name in allCategoryNames) {
        if (!grouped.containsKey(name)) {
          grouped[name] = [];
        }
      }

      setState(() {
        _categoryProducts = grouped;
        _isLoading = false;
      });

    } catch (e) {
      setState(() {
        _error = 'Failed to load products: ${e.toString()}';
        _isLoading = false;
      });
    }
  }

  Future<void> _loadCategoryProducts(String categoryName) async {
    // Already loaded or currently loading
    if (_categoryProducts.containsKey(categoryName) && _categoryProducts[categoryName]!.isNotEmpty) return;
    if (_categoryLoading[categoryName] == true) return;

    setState(() {
      _categoryLoading[categoryName] = true;
      _categoryErrors[categoryName] = null;
    });

    try {
      // Fetch products filtered by category
      final products = await ApiService.instance.fetchProducts(category: categoryName);
      
      setState(() {
        _categoryProducts[categoryName] = products;
        _categoryLoading[categoryName] = false;
      });
    } catch (e) {
      setState(() {
        _categoryErrors[categoryName] = 'Failed to load products';
        _categoryLoading[categoryName] = false;
      });
    }
  }

  void _toggleCategory(String categoryName) {
    setState(() {
      if (_expandedCategory == categoryName) {
        _expandedCategory = null;
      } else {
        _expandedCategory = categoryName;
        // Load products for this category if not loaded
        if (!_categoryProducts.containsKey(categoryName) || _categoryProducts[categoryName]!.isEmpty) {
          _loadCategoryProducts(categoryName);
        }
      }
    });
  }

  void _navigateToProductDetail(BuildContext context, Product product) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => ProductDetailPage(product: product)),
    );
  }

  void _navigateToBuyNow(BuildContext context, Product product) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => BuyNowScreen(product: product)),
    );
  }

  void _showSnack(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message, style: const TextStyle(fontFamily: kFont)),
        backgroundColor: AppColors.primary,
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 2),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    super.build(context);

    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bgColor = Theme.of(context).colorScheme.background;
    final textColor = Theme.of(context).colorScheme.onSurface;
    final mutedColor = isDark ? Colors.white60 : AppColors.outline;

    if (_isLoading) {
      return Scaffold(
        backgroundColor: bgColor,
        body: const Center(
          child: CircularProgressIndicator(color: AppColors.gold),
        ),
      );
    }

    if (_error != null) {
      return Scaffold(
        backgroundColor: bgColor,
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.error_outline, size: 64, color: Colors.red),
              const SizedBox(height: 16),
              Text(
                'Failed to load categories',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600, color: textColor),
              ),
              const SizedBox(height: 8),
              Text(_error!, style: TextStyle(color: mutedColor), textAlign: TextAlign.center),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: _loadAllCategoryProducts,
                style: ElevatedButton.styleFrom(backgroundColor: AppColors.gold),
                child: const Text('Retry'),
              ),
            ],
          ),
        ),
      );
    }

    return Scaffold(
      backgroundColor: bgColor,
      body: Stack(
        children: [
          const Positioned.fill(child: IgnorePointer(child: BrandPatternBackground())),
          SafeArea(
            top: false,
            child: CustomScrollView(
              physics: const AlwaysScrollableScrollPhysics(),
              slivers: [
                _buildStickyTopBar(),
                SliverToBoxAdapter(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Shop by Category',
                          style: TextStyle(fontSize: 28, fontWeight: FontWeight.w700, fontFamily: kFont, color: textColor, letterSpacing: -0.5),
                        ),
                        const SizedBox(height: 6),
                        Text('Discover our latest collections',
                          style: TextStyle(fontSize: 14, fontFamily: kFont, color: mutedColor),
                        ),
                      ],
                    ),
                  ),
                ),
                SliverList(
                  delegate: SliverChildBuilderDelegate(
                    (context, index) {
                      return _CategoryGroupWidget(
                        group: _categoryGroups[index],
                        onCategoryTap: _toggleCategory,
                        expandedCategory: _expandedCategory,
                        categoryProducts: _categoryProducts,
                        categoryLoading: _categoryLoading,
                        categoryErrors: _categoryErrors,
                        onProductTap: (product) => _navigateToProductDetail(context, product),
                        onAddToCart: (product) {
                          CartScope.of(context).addItem(
                            id: product.id,
                            name: product.name,
                            imageUrl: product.imageUrl,
                            price: product.price,
                          );
                          _showSnack('${product.name} added to cart');
                        },
                        onAddToFavourites: (product) {
                          final favourites = FavouritesScope.of(context);
                          favourites.toggleFavourite(product);
                          final isFav = favourites.isFavourite(product.id);
                          _showSnack(isFav ? '${product.name} added to favourites ❤️' : '${product.name} removed from favourites');
                        },
                        onBuyNow: (product) => _navigateToBuyNow(context, product),
                      );
                    },
                    childCount: _categoryGroups.length,
                  ),
                ),
                const SliverToBoxAdapter(child: SizedBox(height: 20)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStickyTopBar() {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bgColor = Theme.of(context).colorScheme.background;

    return SliverAppBar(
      pinned: true,
      floating: true,
      backgroundColor: bgColor.withOpacity(0.95),
      elevation: 0,
      scrolledUnderElevation: 1,
      surfaceTintColor: Colors.transparent,
      shadowColor: isDark ? Colors.white.withOpacity(0.05) : AppColors.outlineVariant,
      automaticallyImplyLeading: false,
      toolbarHeight: 0,
    );
  }
}

// ============================================================
// SUPPORTING CLASSES
// ============================================================

class Category {
  final String name;
  final IconData icon;
  final Color color;

  const Category({
    required this.name,
    required this.icon,
    required this.color,
  });
}

class CategoryGroup {
  final String title;
  final IconData icon;
  final List<Category> categories;

  const CategoryGroup({
    required this.title,
    required this.icon,
    required this.categories,
  });
}

class _CategoryGroupWidget extends StatelessWidget {
  final CategoryGroup group;
  final Function(String) onCategoryTap;
  final String? expandedCategory;
  final Map<String, List<Product>> categoryProducts;
  final Map<String, bool> categoryLoading;
  final Map<String, String?> categoryErrors;
  final Function(Product) onProductTap;
  final Function(Product) onAddToCart;
  final Function(Product) onAddToFavourites;
  final Function(Product) onBuyNow;

  const _CategoryGroupWidget({
    required this.group,
    required this.onCategoryTap,
    required this.expandedCategory,
    required this.categoryProducts,
    required this.categoryLoading,
    required this.categoryErrors,
    required this.onProductTap,
    required this.onAddToCart,
    required this.onAddToFavourites,
    required this.onBuyNow,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final textColor = Theme.of(context).colorScheme.onSurface;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(bottom: 12, left: 4),
            child: Row(
              children: [
                Icon(group.icon, size: 18, color: AppColors.goldDark),
                const SizedBox(width: 8),
                Flexible(
                  child: Text(
                    group.title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600, fontFamily: kFont, color: textColor, letterSpacing: 0.3),
                  ),
                ),
              ],
            ),
          ),
          LayoutBuilder(
            builder: (context, constraints) {
              final totalWidth = constraints.maxWidth;
              final itemCount = group.categories.length;
              final crossAxisCount = itemCount == 3 ? 3 : 4;
              final spacing = 12.0;
              final availableWidth = totalWidth - (spacing * (crossAxisCount - 1));
              final itemWidth = availableWidth / crossAxisCount;

              return Wrap(
                spacing: spacing,
                runSpacing: spacing,
                children: List.generate(itemCount, (index) {
                  final category = group.categories[index];
                  return SizedBox(
                    width: itemWidth,
                    child: _CategoryIcon(
                      category: category,
                      isExpanded: expandedCategory == category.name,
                      onTap: () => onCategoryTap(category.name),
                    ),
                  );
                }),
              );
            },
          ),
          if (expandedCategory != null && group.categories.any((c) => c.name == expandedCategory))
            _ExpandedProductsSection(
              categoryName: expandedCategory!,
              products: categoryProducts[expandedCategory] ?? [],
              isLoading: categoryLoading[expandedCategory] ?? false,
              error: categoryErrors[expandedCategory],
              onProductTap: onProductTap,
              onAddToCart: onAddToCart,
              onAddToFavourites: onAddToFavourites,
              onBuyNow: onBuyNow,
            ),
          const SizedBox(height: 16),
        ],
      ),
    );
  }
}

class _CategoryIcon extends StatelessWidget {
  final Category category;
  final bool isExpanded;
  final VoidCallback onTap;

  const _CategoryIcon({
    required this.category,
    required this.isExpanded,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final textColor = Theme.of(context).colorScheme.onSurface;
    final mutedColor = isDark ? Colors.white60 : AppColors.outline;

    final iconColor = isDark ? AppColors.gold : category.color;

    return GestureDetector(
      onTap: () {
        HapticFeedback.lightImpact();
        onTap();
      },
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            width: 56,
            height: 56,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: isExpanded ? AppColors.gold.withOpacity(0.18) : Colors.transparent,
            ),
            alignment: Alignment.center,
            child: Icon(category.icon, size: 32, color: iconColor),
          ),
          const SizedBox(height: 8),
          Text(
            category.name,
            textAlign: TextAlign.center,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontSize: 11,
              fontWeight: isExpanded ? FontWeight.w700 : FontWeight.w600,
              fontFamily: kFont,
              color: isExpanded ? AppColors.goldDark : textColor,
              height: 1.2,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            '${categoryProducts[category.name]?.length ?? 0} items',
            style: TextStyle(fontSize: 9, fontFamily: kFont, color: mutedColor),
          ),
        ],
      ),
    );
  }

  // Helper to access products
  Map<String, List<Product>> get categoryProducts {
    // This is a hack - in real code, this would be passed down
    // We'll use the expanded products section instead
    return {};
  }
}

class _ExpandedProductsSection extends StatelessWidget {
  final String categoryName;
  final List<Product> products;
  final bool isLoading;
  final String? error;
  final Function(Product) onProductTap;
  final Function(Product) onAddToCart;
  final Function(Product) onAddToFavourites;
  final Function(Product) onBuyNow;

  const _ExpandedProductsSection({
    required this.categoryName,
    required this.products,
    required this.isLoading,
    required this.error,
    required this.onProductTap,
    required this.onAddToCart,
    required this.onAddToFavourites,
    required this.onBuyNow,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final textColor = Theme.of(context).colorScheme.onSurface;
    final screenWidth = MediaQuery.of(context).size.width;
    final screenHeight = MediaQuery.of(context).size.height;
    final horizontalPadding = 32.0;
    final spacing = 12.0;
    final availableWidth = screenWidth - horizontalPadding - spacing;
    final cardWidth = availableWidth / 2;
    final heightRatio = screenHeight < 700 ? 1.5 : 1.65;
    final cardHeight = cardWidth * heightRatio;

    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeInOut,
      child: Padding(
        padding: const EdgeInsets.only(top: 12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 8),
              child: Text(
                "${categoryName}'s Collection",
                style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600, fontFamily: kFont, color: textColor),
              ),
            ),
            if (isLoading)
              SizedBox(
                height: 200,
                child: Center(
                  child: CircularProgressIndicator(color: AppColors.gold),
                ),
              )
            else if (error != null)
              Container(
                height: 100,
                decoration: BoxDecoration(
                  color: Colors.grey[200],
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.error_outline, color: Colors.grey[600]),
                      const SizedBox(height: 4),
                      Text(
                        error!,
                        style: TextStyle(color: Colors.grey[600], fontSize: 12),
                      ),
                      TextButton(
                        onPressed: () {
                          // Reload logic would go here
                        },
                        child: const Text('Retry', style: TextStyle(fontSize: 12)),
                      ),
                    ],
                  ),
                ),
              )
            else if (products.isEmpty)
              Container(
                height: 100,
                decoration: BoxDecoration(
                  color: Colors.grey[200],
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.inventory_2_outlined, size: 32, color: Colors.grey),
                      const SizedBox(height: 8),
                      Text(
                        'No products in $categoryName',
                        style: TextStyle(color: Colors.grey, fontSize: 14, fontFamily: 'Inter'),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Check back later!',
                        style: TextStyle(color: Colors.grey, fontSize: 12, fontFamily: 'Inter'),
                      ),
                    ],
                  ),
                ),
              )
            else
              GridView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: spacing,
                  mainAxisSpacing: spacing,
                  childAspectRatio: cardWidth / cardHeight,
                ),
                itemCount: products.length,
                itemBuilder: (context, index) {
                  final product = products[index];
                  final isFav = FavouritesScope.of(context).isFavourite(product.id);
                  return _ProductCard(
                    product: product,
                    cardWidth: cardWidth,
                    isFavourite: isFav,
                    onTap: () => onProductTap(product),
                    onAddToCart: () => onAddToCart(product),
                    onAddToFavourites: () => onAddToFavourites(product),
                    onBuyNow: () => onBuyNow(product),
                  );
                },
              ),
          ],
        ),
      ),
    );
  }
}

class _ProductCard extends StatelessWidget {
  final Product product;
  final double cardWidth;
  final bool isFavourite;
  final VoidCallback onTap;
  final VoidCallback onAddToCart;
  final VoidCallback onAddToFavourites;
  final VoidCallback onBuyNow;

  const _ProductCard({
    required this.product,
    required this.cardWidth,
    required this.isFavourite,
    required this.onTap,
    required this.onAddToCart,
    required this.onAddToFavourites,
    required this.onBuyNow,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final textColor = Theme.of(context).colorScheme.onSurface;
    final mutedColor = isDark ? Colors.white60 : AppColors.outline;
    final cardColor = Theme.of(context).colorScheme.surface;

    return MediaQuery(
      data: MediaQuery.of(context).copyWith(
        textScaler: MediaQuery.of(context).textScaler.clamp(maxScaleFactor: 1.2),
      ),
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          decoration: BoxDecoration(
            color: cardColor,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: isDark ? Colors.white.withOpacity(0.1) : AppColors.outlineVariant.withOpacity(0.2)),
            boxShadow: isDark ? [] : [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 8, offset: const Offset(0, 2))],
          ),
          clipBehavior: Clip.antiAlias,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                flex: 3,
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    Image.network(
                      product.imageUrl,
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => Container(color: AppColors.primary),
                    ),
                    if (product.isPremium)
                      Positioned(
                        top: 6,
                        left: 6,
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(color: AppColors.goldDark, borderRadius: BorderRadius.circular(4)),
                          child: const Text(
                            'PREMIUM',
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(color: Colors.white, fontSize: 8, fontWeight: FontWeight.w700, letterSpacing: 0.5, fontFamily: kFont),
                          ),
                        ),
                      ),
                    Positioned(
                      top: 6,
                      right: 6,
                      child: GestureDetector(
                        onTap: () {
                          HapticFeedback.lightImpact();
                          onAddToFavourites();
                        },
                        child: Container(
                          padding: const EdgeInsets.all(6),
                          decoration: BoxDecoration(
                            color: isDark ? Colors.grey[800]!.withOpacity(0.9) : Colors.white.withOpacity(0.9),
                            shape: BoxShape.circle,
                            boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.1), blurRadius: 4, offset: const Offset(0, 2))],
                          ),
                          child: Icon(
                            isFavourite ? Icons.favorite_rounded : Icons.favorite_border_rounded,
                            color: isFavourite ? AppColors.saleRed : mutedColor,
                            size: 16,
                          ),
                        ),
                      ),
                    ),
                    Positioned(
                      bottom: 6,
                      right: 6,
                      child: _CategoryProductMenuButton(onAddToCart: onAddToCart, onBuyNow: onBuyNow),
                    ),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      product.name,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(fontSize: cardWidth < 170 ? 10 : 11, fontFamily: kFont, fontWeight: FontWeight.w500, color: textColor),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'Rs.${product.price}',
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(fontSize: cardWidth < 170 ? 11 : 12, fontWeight: FontWeight.w700, fontFamily: kFont, color: textColor),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _CategoryProductMenuButton extends StatelessWidget {
  final VoidCallback? onAddToCart;
  final VoidCallback? onBuyNow;

  const _CategoryProductMenuButton({this.onAddToCart, this.onBuyNow});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final textColor = Theme.of(context).colorScheme.onSurface;

    return PopupMenuButton<String>(
      offset: const Offset(-10, 0),
      color: isDark ? const Color(0xFF1A1A1A) : Colors.white,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 4,
      onSelected: (value) {
        if (value == 'cart' && onAddToCart != null) {
          HapticFeedback.lightImpact();
          onAddToCart!();
        } else if (value == 'buy' && onBuyNow != null) {
          HapticFeedback.lightImpact();
          onBuyNow!();
        }
      },
      itemBuilder: (context) => [
        PopupMenuItem<String>(
          value: 'cart',
          child: Row(
            children: [
              const Icon(Icons.shopping_cart_outlined, size: 18, color: AppColors.primary),
              const SizedBox(width: 10),
              Text('Add to Cart', style: TextStyle(fontFamily: kFont, fontSize: 13, color: textColor)),
            ],
          ),
        ),
        PopupMenuItem<String>(
          value: 'buy',
          child: Row(
            children: [
              const Icon(Icons.flash_on_outlined, size: 18, color: AppColors.goldDark),
              const SizedBox(width: 10),
              Text('Buy Now', style: TextStyle(fontFamily: kFont, fontSize: 13, color: textColor)),
            ],
          ),
        ),
      ],
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
        decoration: BoxDecoration(
          color: AppColors.gold,
          borderRadius: BorderRadius.circular(12),
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.15), blurRadius: 6, offset: const Offset(0, 2))],
        ),
        child: const Icon(Icons.more_horiz, size: 16, color: Colors.black),
      ),
    );
  }
}